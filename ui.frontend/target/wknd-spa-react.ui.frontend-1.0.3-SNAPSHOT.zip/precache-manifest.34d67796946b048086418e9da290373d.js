self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "82152bd51cf7bd7c9720c185edde8ad6",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "f8d4b1291af2630a53ac",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.fd22afae.chunk.css"
  },
  {
    "revision": "f48319de3545b045aa2c",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.481ebcb8.chunk.js"
  },
  {
    "revision": "a997066f5a8da487bf2934a8b8fd42fb",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.481ebcb8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f8d4b1291af2630a53ac",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.e037cc1a.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/media/icon-back.19a5bdab.svg"
  }
]);